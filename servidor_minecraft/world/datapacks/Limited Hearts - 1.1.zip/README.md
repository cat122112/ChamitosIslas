# Limited Hearts (Datapack)
This pack is based on the `Attrition` datapack.
Everytime you die, you lose a single heart.
Eating an enchanted golden apple restores one heart.

## How to install
Simply put the file `Limited Hearts.zip` inside the `{WORLD}/datapacks` directory.